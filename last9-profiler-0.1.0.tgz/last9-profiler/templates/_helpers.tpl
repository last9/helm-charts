{{/*
Expand the name of the chart.
*/}}
{{- define "last9-profiler.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "last9-profiler.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "last9-profiler.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels — applied to every resource.
*/}}
{{- define "last9-profiler.labels" -}}
helm.sh/chart: {{ include "last9-profiler.chart" . }}
{{ include "last9-profiler.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: last9-profiling
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Selector labels — used by DaemonSet's pod selector. Must be stable across upgrades.
*/}}
{{- define "last9-profiler.selectorLabels" -}}
app.kubernetes.io/name: {{ include "last9-profiler.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
ServiceAccount name to use.
*/}}
{{- define "last9-profiler.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "last9-profiler.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- required "serviceAccount.name is required when serviceAccount.create=false" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/* Existing customer-owned Authorization Secret name. */}}
{{- define "last9-profiler.authorizationSecretName" -}}
{{- .Values.last9.authorization.existingSecret -}}
{{- end -}}

{{/*
Static OpenTelemetry resource attributes configured through chart values.
*/}}
{{- define "last9-profiler.resourceAttributes" -}}
{{- $attributes := list -}}
{{- with .Values.deploymentEnvironment -}}
{{- $attributes = append $attributes (printf "deployment.environment.name=%v" .) -}}
{{- end -}}
{{- with .Values.clusterName -}}
{{- $attributes = append $attributes (printf "k8s.cluster.name=%v" .) -}}
{{- end -}}
{{- join "," $attributes -}}
{{- end -}}
