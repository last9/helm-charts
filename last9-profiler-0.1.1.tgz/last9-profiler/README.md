# Last9 profiler Helm chart

This is a customer-installable chart for the upstream OpenTelemetry eBPF
profiler. It runs one DaemonSet pod on each eligible Linux worker and sends
profile data to a customer-assigned Last9 OTLP endpoint.

## Supported release

The supported public chart repository is
<https://last9.github.io/helm-charts>. This first release supports exactly
chart version `0.1.1`. Every install, pull, show, and upgrade command below
pins `--version 0.1.1`.

Older immutable artifacts may remain downloadable, but are unsupported. A
defect is repaired by publishing a higher chart version; an existing version
is never overwritten or reused. There is no rollback promise for this first
release. The supported repair path is upgrade to the current supported
version; otherwise uninstall and reinstall the current version.

## What customers can inspect

Customers can inspect this chart, its templates, values schema, and the
rendered OpenTelemetry Collector configuration. Proprietary source,
control-plane processing, and repository history are not part of the package.
Direct template edits, chart forks, and undocumented values are unsupported.

The chart deploys two containers in one DaemonSet pod:

- `otel/opentelemetry-collector-ebpf-profiler:0.158.0`@
  `sha256:9dca72f7a886912e3406d11cab995914d8caa5f991824fed1f93b18f04796f4a`
- `otel/opentelemetry-collector:0.158.0`@
  `sha256:5b97e6e3550ec6e48a71dba6f6304d349a293af8df4ee1f51da67be94fce2ecd`

The first image is documented by the [upstream eBPF profiler project](https://github.com/open-telemetry/opentelemetry-ebpf-profiler)
and its [official releases](https://github.com/open-telemetry/opentelemetry-ebpf-profiler/releases),
and the [upstream distribution source](https://github.com/open-telemetry/opentelemetry-collector-releases/tree/main/distributions/otelcol-ebpf-profiler).
The second is the [upstream Collector release distribution](https://github.com/open-telemetry/opentelemetry-collector-releases)
and its [official releases](https://github.com/open-telemetry/opentelemetry-collector-releases/releases).
Both images are Apache-2.0 licensed; see the [license text](https://www.apache.org/licenses/LICENSE-2.0).

You may mirror either image by changing only
`images.profiler.repository` or `images.egress.repository`. The tag and
digest are fixed and schema-validated; a mirror must preserve `0.158.0` and
the digest shown above.

## Prerequisites

- Kubernetes `>=1.27` and Linux worker nodes. Control-plane nodes are excluded.
- A kernel and runtime that provide the profiler's eBPF/BTF support, `/proc`,
  `/sys`, and a writable bpffs at `/sys/fs/bpf` (the upstream profiler's
  supported kernel requirements also apply).
- Helm 3, permission to use the required host access, and permission to read
  the listed workload metadata through cluster RBAC.
- Image-pull access to the selected repositories and outbound TLS egress from
  the egress container to the assigned Last9 endpoint.
- An administrator must set `security.acceptHostAccess=true` explicitly.

## Data and network boundary

Outbound data consists of profile samples, stacks and frames, executable/build
identifiers, and enriched Kubernetes workload, container, node, and namespace
metadata. This chart does not collect general logs, traces, or metrics.

Profile payloads are not persisted to disk or to the host. The chart creates no
inbound Service, `hostPort`, or `hostNetwork`. Collector self-metrics are
available only through an authenticated administrator's `kubectl
port-forward` to `127.0.0.1:8888`; there is no Service or container port for
metrics.

## Privileges and host access

### host-access-and-privileges

The profiler container uses pod-level `hostPID` so it can see processes on the
node, runs as root, and uses the supported capabilities `BPF`, `PERFMON`,
`SYS_ADMIN`, `SYS_PTRACE`, `IPC_LOCK`, `SYSLOG`, and `SYS_RESOURCE`. It mounts
host `/proc` read-only, host `/sys` read-only, and `/sys/fs/bpf` writable for
eBPF maps and programs.
These are deliberate administrator-visible permissions.

The default uses explicit capabilities and `privileged: false`.
`security.privilegedCompatibility=true` is an explicit opt-in for runtimes
that cannot use the supported capability set; it broadens the profiler container to
privileged mode. The egress container remains non-root, drops all
capabilities, disallows privilege escalation, uses a read-only root
filesystem, and uses the runtime default seccomp profile.

Both containers share a pod and pod-level host-PID visibility. Treat the
same-pod boundary as trusted: egress hardening limits its own filesystem and
capabilities but is not a substitute for node isolation. Remote egress is TLS
only and the external Authorization header value is read from the existing
Secret by egress.

Only the profiler receives the projected Kubernetes service-account token. The
RBAC role is read-only (`get`, `list`, `watch`) for `pods`, `namespaces`, and
`nodes`, plus `replicasets`, `deployments`, `daemonsets`, `statefulsets`,
`jobs`, and `cronjobs`. These resources are needed to enrich workload,
container, node, namespace, and owner-reference metadata; Secrets and
ConfigMaps are not granted.

Schedule only on Linux workers. Required node affinity excludes both
`node-role.kubernetes.io/control-plane` and
`node-role.kubernetes.io/master`; tolerations and additional selectors may
narrow placement but cannot override those safety rules.

`tolerations` defaults to `[{operator: Exists}]`, tolerating every node
taint, so the DaemonSet schedules on all Linux worker nodes out of the box —
including tainted/dedicated node pools. Narrow or clear this list to restrict
placement to nodes with matching taints instead.

Set `priorityClassName` to a
[PriorityClass](https://kubernetes.io/docs/concepts/scheduling-eviction/pod-priority-preemption/)
with a high priority value so profiler pods are scheduled — and, under node
pressure, preempt lower-priority pods — before other workloads come up on the
node. Create the PriorityClass separately (it is cluster-scoped and outside
this chart), for example:

```yaml
apiVersion: scheduling.k8s.io/v1
kind: PriorityClass
metadata:
  name: last9-profiler-critical
value: 1000000
globalDefault: false
description: "Ensures last9-profiler is scheduled before other workloads on the node."
```

then set `priorityClassName: last9-profiler-critical` in `values.yaml`.

## Installation lifecycle

### 1. Pull the pinned public release

```bash
helm repo add last9 https://last9.github.io/helm-charts
helm repo update
helm search repo last9/last9-profiler --versions
helm pull last9/last9-profiler --version 0.1.1 \
  --destination /secure/path/chart-cache
sha256sum /secure/path/chart-cache/last9-profiler-0.1.1.tgz
helm show readme /secure/path/chart-cache/last9-profiler-0.1.1.tgz
```

Get the server OTLP endpoint and Basic authorization value from [Integrations
→ OpenTelemetry](https://app.last9.io/integrations?integration=OpenTelemetry)
in Last9, or ask an organization admin/Last9 contact for the server ingestion
credentials. Use the profiles endpoint supplied for this chart; it must end in
`/v1/profiles`. Do not use a query token or put credentials in a tracked file.

The SHA-256 output must match the `digest` for version `0.1.1` in the public
repository index. Keep that exact archive for the install and upgrade commands
below; do not resolve the chart again from the repository after checking it.
The installation guide is [Last9 Kubernetes profiling](https://last9.io/docs/profiling/kubernetes).

### 2. Create the namespace and credential Secret

Create the Secret before installing, in the same namespace as the release.
The chart never creates, imports, prints, or stores this Secret. Use a secure
file or an external secret manager; never put a token on a command line.

```bash
kubectl create namespace last9-profiler --dry-run=client -o yaml | kubectl apply -f -
kubectl create secret generic last9-profiler-credentials \
  --namespace last9-profiler \
  --from-file=authorization=/secure/path/profiling-authorization \
  --dry-run=client -o yaml | kubectl apply -f -
```

For an external secret manager, create the same-namespace Secret with the key
named `authorization` (or set `last9.authorization.existingSecretKey` to its
existing key). Its contents are passed verbatim as the HTTP `Authorization`
header value, for example `Basic <base64-credentials>`.

### 3. Prepare values and install

Use a values file outside the chart. Replace the endpoint marker with the
customer-assigned public HTTPS OTLP/HTTP profiles URL; leaving the marker in
place intentionally fails chart validation.

```yaml
last9:
  ingestEndpoint: "https://REPLACE_WITH_CUSTOMER_ASSIGNED_HOSTNAME/v1/profiles"
  authorization:
    existingSecret: last9-profiler-credentials
    existingSecretKey: authorization
security:
  acceptHostAccess: true
```

The endpoint must be an HTTPS DNS hostname with the exact `/v1/profiles` path
and either implicit port `443` or explicit `:443`; IP addresses, internal
cluster addresses, query strings, and other paths or ports are rejected.

```bash
helm install last9-profiler /secure/path/chart-cache/last9-profiler-0.1.1.tgz \
  --namespace last9-profiler \
  --values /secure/path/last9-profiler-values.yaml
helm status last9-profiler --namespace last9-profiler
kubectl rollout status daemonset/last9-profiler --namespace last9-profiler --timeout=180s
```

The endpoint marker is documentation-only and is rejected by the chart. Do
not copy it unchanged into a real values file.

### 4. Opt in workloads and verify

Add this label to the pod template of each workload to profile:

```yaml
metadata:
  labels:
    last9.profiling/enabled: "true"
```

The profile pipeline drops records without that exact label value before
remote export. Verify the pods and logs with authenticated cluster access.
Self-metrics require only this loopback port-forward:

```bash
kubectl port-forward daemonset/last9-profiler 8888:8888 \
  --namespace last9-profiler
curl --fail --silent http://127.0.0.1:8888/metrics \
  | grep otelcol_processor_filter_profiles_filtered
```

The filtered-profile counter is a local diagnostic; the chart does not expose
it through a Service or container port.

## Profile names and flamegraphs

The chart transports OTLP profiles; it does not perform executable
symbolization. Readable function names depend on the profiled runtime and the
symbols available to the upstream eBPF profiler. Stripped or minimal images,
including shell-only BusyBox workloads, can therefore contain `[unknown]`
frames even when collection and ingestion are healthy.

Use a symbolizable application (for example, a Go or Java workload) when
validating readable flamegraphs. If every workload produces unknown frames,
check the upstream profiler/runtime support and the raw profile tables before
changing chart values. Existing unknown frames are not re-symbolized later.

### 5. Rotate credentials and restart

Replace the existing same-namespace Secret from a secure file, then restart
the DaemonSet so new egress containers read the new value:

```bash
kubectl create secret generic last9-profiler-credentials \
  --namespace last9-profiler \
  --from-file=authorization=/secure/path/new-profiling-authorization \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl rollout restart daemonset/last9-profiler --namespace last9-profiler
kubectl rollout status daemonset/last9-profiler --namespace last9-profiler --timeout=180s
```

### 6. Upgrade, repair, and uninstall

Upgrade only to the currently supported chart version. Do not overwrite or
reuse `0.1.1`; a defect requires a higher published version.

```bash
helm upgrade last9-profiler /secure/path/chart-cache/last9-profiler-0.1.1.tgz \
  --namespace last9-profiler \
  --values /secure/path/last9-profiler-values.yaml
```

For a later repair release, replace every `0.1.1` in the command with the
higher supported version and repeat the pinned pull and SHA-256 check. There
is no rollback promise.

```bash
helm uninstall last9-profiler --namespace last9-profiler
kubectl get secret last9-profiler-credentials --namespace last9-profiler
```

Uninstall removes chart-managed resources only. The customer-owned Secret
survives and can be removed separately under the customer's retention policy.

## Configuration boundary

The supported customer inputs are the endpoint, an existing Secret reference,
resource labels such as deployment environment and cluster name, image
repository mirrors, resource limits, and narrower placement settings. Image
tags and digests, the profiling opt-in label, TLS requirement, host access
acknowledgement, and the read-only RBAC boundary are fixed by the chart.
